def main():
    print('Hi from puzzlebot_description.')


if __name__ == '__main__':
    main()
